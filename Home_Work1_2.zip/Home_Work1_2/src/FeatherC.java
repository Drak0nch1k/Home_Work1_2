public enum FeatherC {
    BLUE, BROWN;
}
